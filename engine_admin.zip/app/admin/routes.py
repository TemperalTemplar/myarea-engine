"""
MyArea Game Engine — Admin Panel
/admin — requires is_admin=True
"""
import functools
from flask import Blueprint, render_template, redirect, url_for, flash, request, abort
from flask_login import login_required, current_user
from app import db

admin_bp = Blueprint("admin", __name__)


def admin_required(fn):
    @functools.wraps(fn)
    def wrapper(*args, **kwargs):
        if not current_user.is_authenticated or not current_user.is_admin:
            abort(403)
        return fn(*args, **kwargs)
    return wrapper


# ─── Dashboard ────────────────────────────────────────────────
@admin_bp.route("/")
@login_required
@admin_required
def index():
    from app.models import User, Player, Gang, JobLog, AttackLog, Item, JobTemplate
    from sqlalchemy import desc
    stats = {
        "players":    Player.query.count(),
        "users":      User.query.count(),
        "banned":     User.query.filter_by(is_banned=True).count(),
        "gangs":      Gang.query.count(),
        "jobs_today": JobLog.query.filter(
            JobLog.attempted_at >= db.func.current_date()
        ).count(),
        "attacks_today": AttackLog.query.filter(
            AttackLog.attacked_at >= db.func.current_date()
        ).count(),
        "items":      Item.query.count(),
        "job_templates": JobTemplate.query.count(),
    }
    recent = Player.query.order_by(desc(Player.created_at)).limit(10).all()
    top = Player.query.order_by(desc(Player.level), desc(Player.experience)).limit(5).all()
    return render_template("admin/index.html", stats=stats, recent=recent, top=top)


# ─── Players ──────────────────────────────────────────────────
@admin_bp.route("/players")
@login_required
@admin_required
def players():
    from app.models import Player, User
    from sqlalchemy import desc
    q = request.args.get("q", "").strip()
    page = request.args.get("page", 1, type=int)
    query = Player.query
    if q:
        query = query.join(User).filter(
            (Player.display_name.ilike(f"%{q}%")) |
            (User.username.ilike(f"%{q}%"))
        )
    pagination = query.order_by(desc(Player.level)).paginate(
        page=page, per_page=30, error_out=False
    )
    return render_template("admin/players.html", pagination=pagination, q=q)


@admin_bp.route("/players/<int:player_id>")
@login_required
@admin_required
def player_detail(player_id):
    from app.models import Player, JobLog, AttackLog
    from sqlalchemy import desc, or_
    player = Player.query.get_or_404(player_id)
    recent_jobs = JobLog.query.filter_by(player_id=player_id).order_by(
        desc(JobLog.attempted_at)).limit(20).all()
    recent_attacks = AttackLog.query.filter(
        or_(AttackLog.attacker_id == player_id, AttackLog.defender_id == player_id)
    ).order_by(desc(AttackLog.attacked_at)).limit(20).all()
    return render_template("admin/player_detail.html",
                           player=player,
                           recent_jobs=recent_jobs,
                           recent_attacks=recent_attacks)


@admin_bp.route("/players/<int:player_id>/ban", methods=["POST"])
@login_required
@admin_required
def ban_player(player_id):
    from app.models import Player
    player = Player.query.get_or_404(player_id)
    user = player.user
    if user.id == current_user.id:
        flash("You can't ban yourself.", "danger")
        return redirect(url_for("admin.player_detail", player_id=player_id))
    user.is_banned = not user.is_banned
    db.session.commit()
    flash(f"{'Banned' if user.is_banned else 'Unbanned'} {player.display_name}.", "success")
    return redirect(url_for("admin.player_detail", player_id=player_id))


@admin_bp.route("/players/<int:player_id>/edit", methods=["POST"])
@login_required
@admin_required
def edit_player(player_id):
    from app.models import Player
    player = Player.query.get_or_404(player_id)
    try:
        player.cash   = int(request.form.get("cash", player.cash))
        player.level  = int(request.form.get("level", player.level))
        player.energy = int(request.form.get("energy", player.energy))
        player.health = int(request.form.get("health", player.health))
    except ValueError:
        flash("Invalid values.", "danger")
        return redirect(url_for("admin.player_detail", player_id=player_id))
    db.session.commit()
    flash(f"Player {player.display_name} updated.", "success")
    return redirect(url_for("admin.player_detail", player_id=player_id))


# ─── Gangs ────────────────────────────────────────────────────
@admin_bp.route("/gangs")
@login_required
@admin_required
def gangs():
    from app.models import Gang
    from sqlalchemy import desc
    page = request.args.get("page", 1, type=int)
    pagination = Gang.query.order_by(desc(Gang.territory_points)).paginate(
        page=page, per_page=30, error_out=False
    )
    return render_template("admin/gangs.html", pagination=pagination)


@admin_bp.route("/gangs/<int:gang_id>/delete", methods=["POST"])
@login_required
@admin_required
def delete_gang(gang_id):
    from app.models import Gang, Player
    gang = Gang.query.get_or_404(gang_id)
    # Remove all members from gang
    for member in gang.members:
        member.gang_id = None
        member.gang_rank = None
    db.session.delete(gang)
    db.session.commit()
    flash(f"Gang {gang.name} deleted.", "success")
    return redirect(url_for("admin.gangs"))


# ─── Job Templates ────────────────────────────────────────────
@admin_bp.route("/jobs")
@login_required
@admin_required
def jobs():
    from app.models import JobTemplate
    jobs = JobTemplate.query.order_by(JobTemplate.min_level, JobTemplate.energy_cost).all()
    return render_template("admin/jobs.html", jobs=jobs)


@admin_bp.route("/jobs/<int:job_id>/toggle", methods=["POST"])
@login_required
@admin_required
def toggle_job(job_id):
    from app.models import JobTemplate
    job = JobTemplate.query.get_or_404(job_id)
    job.is_active = not job.is_active
    db.session.commit()
    flash(f"Job '{job.name}' {'enabled' if job.is_active else 'disabled'}.", "success")
    return redirect(url_for("admin.jobs"))


# ─── Items ────────────────────────────────────────────────────
@admin_bp.route("/items")
@login_required
@admin_required
def items():
    from app.models import Item
    items = Item.query.order_by(Item.category, Item.buy_price).all()
    return render_template("admin/items.html", items=items)


@admin_bp.route("/items/<int:item_id>/toggle", methods=["POST"])
@login_required
@admin_required
def toggle_item(item_id):
    from app.models import Item
    item = Item.query.get_or_404(item_id)
    item.is_active = not item.is_active
    db.session.commit()
    flash(f"Item '{item.name}' {'enabled' if item.is_active else 'disabled'}.", "success")
    return redirect(url_for("admin.items"))


# ─── Notify all players ───────────────────────────────────────
@admin_bp.route("/notify", methods=["GET", "POST"])
@login_required
@admin_required
def notify_all():
    from app.models import Player, Notification
    if request.method == "POST":
        title   = request.form.get("title", "").strip()
        message = request.form.get("message", "").strip()
        link    = request.form.get("link", "").strip() or None
        if not title or not message:
            flash("Title and message required.", "danger")
            return redirect(url_for("admin.notify_all"))
        players = Player.query.all()
        for p in players:
            n = Notification(
                player_id=p.id, type="system",
                title=title, message=message, link=link,
            )
            db.session.add(n)
        db.session.commit()
        flash(f"Notification sent to {len(players)} players.", "success")
        return redirect(url_for("admin.index"))
    return render_template("admin/notify.html")


# ─── Re-seed game data ────────────────────────────────────────
@admin_bp.route("/seed", methods=["POST"])
@login_required
@admin_required
def reseed():
    from app.cli import _seed_jobs, _seed_properties, _seed_items
    from app.models import JobTemplate, PropertyTemplate, Item
    from slugify import slugify
    _seed_jobs(db, JobTemplate)
    _seed_properties(db, PropertyTemplate)
    _seed_items(db, Item, slugify)
    db.session.commit()
    flash("Game data re-seeded (new entries only, existing unchanged).", "success")
    return redirect(url_for("admin.index"))

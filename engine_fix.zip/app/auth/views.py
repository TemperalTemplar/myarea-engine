from flask import render_template, redirect, url_for, flash, request
from flask_login import login_user, logout_user, login_required, current_user
from app.auth.routes import auth_bp
from app import db


@auth_bp.route("/login", methods=["GET", "POST"])
def login():
    if current_user.is_authenticated:
        return redirect(url_for("game.dashboard"))

    if request.method == "POST":
        from app.models import User
        identifier = request.form.get("identifier", "").strip()
        password   = request.form.get("password", "")
        remember   = bool(request.form.get("remember"))

        user = (User.query.filter_by(username=identifier).first() or
                User.query.filter_by(email=identifier).first())

        if user and user.check_password(password):
            if user.is_banned:
                flash("Your account has been suspended.", "danger")
                return redirect(url_for("auth.login"))
            from datetime import datetime, timezone
            user.last_login = datetime.now(timezone.utc)
            db.session.commit()
            login_user(user, remember=remember)
            return redirect(request.args.get("next") or url_for("game.dashboard"))

        flash("Invalid username or password.", "danger")

    return render_template("auth/login.html")


@auth_bp.route("/register", methods=["GET", "POST"])
def register():
    if current_user.is_authenticated:
        return redirect(url_for("game.dashboard"))

    if request.method == "POST":
        from app.models import User, Player
        from slugify import slugify

        username  = request.form.get("username", "").strip()
        email     = request.form.get("email", "").strip().lower()
        password  = request.form.get("password", "")
        password2 = request.form.get("password2", "")

        errors = []
        if len(username) < 3 or len(username) > 32:
            errors.append("Username must be 3–32 characters.")
        if len(password) < 8:
            errors.append("Password must be at least 8 characters.")
        if password != password2:
            errors.append("Passwords do not match.")
        if User.query.filter_by(username=username).first():
            errors.append("Username already taken.")
        if User.query.filter_by(email=email).first():
            errors.append("Email already registered.")

        if errors:
            for e in errors:
                flash(e, "danger")
            return render_template("auth/register.html", username=username, email=email)

        from flask import current_app
        user = User(username=username, email=email)
        user.set_password(password)
        db.session.add(user)
        db.session.flush()

        player = Player(
            user_id=user.id,
            slug=slugify(username),
            display_name=username,
            cash=current_app.config["NEW_PLAYER_CASH"],
            energy=current_app.config["NEW_PLAYER_ENERGY"],
            stamina=current_app.config["NEW_PLAYER_STAMINA"],
            health=current_app.config["NEW_PLAYER_HEALTH"],
        )
        db.session.add(player)
        db.session.commit()
        login_user(user)
        flash(f"Welcome to MyArea, {username}! Your criminal career begins now.", "success")
        return redirect(url_for("game.dashboard"))

    return render_template("auth/register.html")


@auth_bp.route("/logout")
@login_required
def logout():
    logout_user()
    flash("You've been logged out.", "info")
    return redirect(url_for("auth.login"))
